import React from "react";
 
const Cart=()=>{
    return(
        <div>
        <h5 >No items Added to the Cart</h5>
        </div>
    )
}

export default Cart;